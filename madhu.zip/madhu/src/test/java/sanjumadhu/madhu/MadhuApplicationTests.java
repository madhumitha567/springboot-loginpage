package sanjumadhu.madhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadhuApplicationTests {

	@Test
	void contextLoads() {
	}

}
